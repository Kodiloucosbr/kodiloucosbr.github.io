from resolveurl.resolver import ResolveUrl, ResolverError
import re

class CloudMailRuResolver(ResolveUrl):
    name = 'CloudMailRu'
    base_domain = 'cloud.mail.ru'

    def __init__(self):
        super(CloudMailRuResolver, self).__init__()

    def get_media_url(self, host, media_id):
        # No need to fetch the URL, as the content is directly provided
        html = host
        strurl = self.extract_video_url(html)
        if strurl:
            return strurl
        raise ResolverError('No playable video found.')

    def extract_video_url(self, html):
        # Extracting the video URL from the provided HTML content
        match = re.search(r'<link>(https://cloclo(?:5[0-9]|6[0-9]).cloud.mail.ru/.+?)</link>', html)
        if match:
            return match.group(1)
        return None

    def resolve(self, url):
        if self.base_domain in url and re.match(r'https://cloclo(?:5[0-9]|6[0-9]).cloud.mail.ru/', url):
            return url
        else:
            # Try to replace the domain with the correct one
            correct_domain = url.replace(url.split('.')[1], self.base_domain.split('.')[1])
            return correct_domain
