"""
    Plugin for ResolveURL
    Copyright (C) 2024 [Seu Nome]

    Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
    sob os termos da Licença Pública Geral GNU, conforme publicada pela
    Fundação do Software Livre, tanto a versão 3 da Licença como (a seu critério)
    qualquer versão posterior.

    Este programa é distribuído na esperança de que seja útil,
    mas SEM NENHUMA GARANTIA; sem mesmo a garantia implícita de
    COMERCIALIZAÇÃO ou ADEQUAÇÃO A UM PROPÓSITO ESPECÍFICO. Consulte os detalhes
    da Licença Pública Geral GNU para obter mais detalhes.

    Você deve ter recebido uma cópia da Licença Pública Geral GNU
    junto com este programa. Se não, veja <http://www.gnu.org/licenses/>.
"""

import re
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

class WarezCdnResolver(ResolveUrl):
    name = 'WarezCDN'
    domains = ['warezcdn.com', 'workerproxy.warezcdn.workers.dev', 'embed.warezcdn.com']
    pattern = r'https?://(?:www\.)?(warezcdn\.com|workerproxy\.warezcdn\.workers\.dev|embed\.warezcdn\.com)/\w+/([a-zA-Z0-9]+)'

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': common.RAND_UA}
        html = self.net.http_GET(web_url, headers=headers).content
        match = re.search(r'<source\s+src="([^"]+)', html)
        if match:
            return match.group(1)
        raise ResolverError('No playable video found.')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/video/{media_id}')