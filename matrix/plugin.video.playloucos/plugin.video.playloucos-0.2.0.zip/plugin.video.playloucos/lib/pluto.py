# -*- coding: utf-8 -*-
import uuid
import xbmc
import xbmcgui
from urllib.parse import quote_plus
from datetime import datetime, timedelta, timezone

try:
    from lib.ClientScraper import cfscraper, USER_AGENT
except ImportError:
    from ClientScraper import cfscraper, USER_AGENT

def playlist_pluto():
    channels_kodi = []
    channels_info = []

    try:
        deviceid = str(uuid.uuid4())
        time_brazil = datetime.now(timezone.utc)

        from_date = time_brazil
        to_date = from_date + timedelta(days=1)
        from_str = from_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        to_str = to_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        url = f"http://api.pluto.tv/v2/channels?start={from_str}&stop={to_str}"
        channels = cfscraper.get(url).json()

        for channel in channels:
            if channel.get('number', 0) > 0:
                channel_info = {
                    'name': channel.get('name'),
                    'thumbnail': channel.get('logo', {}).get('path'),
                    'current_program': None,
                    'next_program': None,
                    'url': None
                }

                stream_url = channel.get('stitched', {}).get('urls', [{}])[0].get('url')
                if stream_url:
                    stream_url = stream_url.replace('&deviceMake=', '&deviceMake=Firefox')
                    stream_url = stream_url.replace('&deviceType=', '&deviceType=web')
                    stream_url = stream_url.replace('&deviceId=unknown', f'&deviceId={deviceid}')
                    stream_url = stream_url.replace('&deviceModel=', '&deviceModel=web')
                    stream_url = stream_url.replace('&deviceVersion=unknown', '&deviceVersion=82.0')
                    stream_url = stream_url.replace('&appName=&', '&appName=web&')
                    stream_url = stream_url.replace('&appVersion=&', '&appVersion=5.9.1')
                    stream_url = stream_url.replace('&sid=', f'&sid={deviceid}&sessionID={deviceid}')
                    stream_url = stream_url.replace('&deviceDNT=0', '&deviceDNT=false')
                    stream_url += f"&serverSideAds=false&terminate=false&clientDeviceType=0&clientModelNumber=na&clientID={deviceid}"
                    stream_url += '|User-Agent=' + quote_plus(USER_AGENT)
                    channel_info['url'] = stream_url

                now = None
                for timeline in channel.get('timelines', []):
                    start_dt = datetime.fromisoformat(timeline['start'].replace('Z', '+00:00'))
                    end_dt = datetime.fromisoformat(timeline['stop'].replace('Z', '+00:00'))

                    if start_dt <= time_brazil <= end_dt:
                        now = end_dt
                        channel_info['current_program'] = {
                            'title': timeline['episode']['name'],
                            'description': timeline['episode'].get('description', ''),
                            'start_time': start_dt.isoformat(),
                            'end_time': end_dt.isoformat()
                        }

                    if now and start_dt <= now < end_dt:
                        channel_info['next_program'] = {
                            'title': timeline['episode']['name'],
                            'description': timeline['episode'].get('description', ''),
                            'start_time': start_dt.isoformat(),
                            'end_time': end_dt.isoformat()
                        }

                channels_info.append(channel_info)

    except Exception as e:
        xbmc.log(f'[PlutoTV] Erro ao carregar canais: {e}', xbmc.LOGERROR)

    time_format = "%Y-%m-%dT%H:%M:%S%z"
    if channels_info:
        for n, channel in enumerate(channels_info):
            desc = ''
            number = str(n + 1)
            channel_name = channel.get('name', number)
            thumbnail = channel.get('thumbnail', '')
            stream = channel.get('url', '')
            current_program = channel.get('current_program', {})
            program_now = current_program.get('title', '')
            program_now_start = current_program.get('start_time', '')
            desc_program_now = current_program.get('description', '')
            program_end = channel.get('next_program', {})
            program_end_title = program_end.get('title', '')
            program_end_start = program_end.get('start_time', '')
            desc_program_end = program_end.get('description', '')

            if program_now_start:
                try:
                    time_obj = datetime.strptime(program_now_start, time_format)
                    new_time_obj = time_obj - timedelta(hours=3)
                    start = new_time_obj.strftime("%H:%M")
                    desc += f'[COLOR yellow][{start}] {program_now}[/COLOR]\n({desc_program_now})\n'
                except Exception:
                    pass

            if program_end_start:
                try:
                    time_obj_ = datetime.strptime(program_end_start, time_format)
                    new_time_obj_ = time_obj_ - timedelta(hours=3)
                    start_ = new_time_obj_.strftime("%H:%M")
                    desc += f'[COLOR yellow][{start_}] {program_end_title}[/COLOR]\n({desc_program_end})\n'
                except Exception:
                    pass

            if program_now:
                channel_name += ' - [COLOR yellow]' + program_now + '[/COLOR]'

            channels_kodi.append((channel_name, desc, thumbnail, stream))
    else:
        xbmcgui.Dialog().notification('Pluto TV', 'Nenhum canal encontrado.', xbmcgui.NOTIFICATION_ERROR)

    return channels_kodi
