import xbmc
import xbmcvfs
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib.request, urllib.parse
import re
import sys
import os
import gzip
from io import StringIO
from six.moves import urllib_request
from six.moves.urllib.parse import unquote_plus, quote_plus
from six import PY3

# Module level logging flags
module_log_enabled = False
http_debug_log_enabled = False

if PY3:
    unicode = str

LIST = "list"
THUMBNAIL = "thumbnail"
MOVIES = "movies"
TV_SHOWS = "tvshows"
SEASONS = "seasons"
EPISODES = "episodes"
OTHER = "other"

ALL_VIEW_CODES = {
    'list': {
        'skin.confluence': 50,
        'skin.aeon.nox': 50,
        'skin.droid': 50,
        'skin.quartz': 50,
        'skin.re-touched': 50,
    },
    'thumbnail': {
        'skin.confluence': 500,
        'skin.aeon.nox': 500,
        'skin.droid': 51,
        'skin.quartz': 51,
        'skin.re-touched': 500,
    },
    'movies': {
        'skin.confluence': 515,
        'skin.aeon.nox': 500,
        'skin.droid': 51,
        'skin.quartz': 52,
        'skin.re-touched': 500,
    },
    'tvshows': {
        'skin.confluence': 515,
        'skin.aeon.nox': 500,
        'skin.droid': 51,
        'skin.quartz': 52,
        'skin.re-touched': 500,
    },
    'seasons': {
        'skin.confluence': 50,
        'skin.aeon.nox': 50,
        'skin.droid': 50,
        'skin.quartz': 52,
        'skin.re-touched': 50,
    },
    'episodes': {
        'skin.confluence': 503,
        'skin.aeon.nox': 518,
        'skin.droid': 50,
        'skin.quartz': 52,
        'skin.re-touched': 550,
    },
}

def log(message):
    xbmc.log(message)

def _log(message):
    if module_log_enabled:
        xbmc.log("plugintools." + message)

def get_params():
    try:
        _log("get_params")
        param_string = sys.argv[2]
        _log("get_params " + str(param_string))
        commands = {}
        if param_string:
            split_commands = param_string[param_string.find('?') + 1:].split('&')
            for command in split_commands:
                _log("get_params command=" + str(command))
                if len(command) > 0:
                    if "=" in command:
                        split_command = command.split('=')
                        key = split_command[0]
                        value = urllib.parse.unquote_plus(split_command[1])
                        commands[key] = value
                    else:
                        commands[command] = ""
        _log("get_params " + repr(commands))
        return commands
    except Exception as e:
        log(f"Error in get_params: {str(e)}")
        return {}

def add_item(action="", title="", plot="", url="", thumbnail="", fanart="", show="", episode="", extra="", page="", info_labels=None, isPlayable=False, folder=True):
    try:
        _log(f"add_item action=[{action}] title=[{title}] url=[{url}] thumbnail=[{thumbnail}] fanart=[{fanart}] show=[{show}] episode=[{episode}] extra=[{extra}] page=[{page}] isPlayable=[{isPlayable}] folder=[{folder}]")
        listitem = xbmcgui.ListItem(label=title)
        listitem.setArt({
            'poster': 'poster.png',
            'banner': 'banner.png',
            'icon': thumbnail,
            'thumb': thumbnail,
            'poster': thumbnail,
            'fanart': fanart
        })
        if info_labels is None:
            info_labels = {"Title": title, "Plot": plot}
        infotag = listitem.getVideoInfoTag()
        infotag.setTitle(info_labels.get("Title", ""))
        infotag.setPlot(info_labels.get("Plot", ""))
        if fanart:
            listitem.setProperty('fanart_image', fanart)
            xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)
        itemurl = f'{sys.argv[0]}?action={action}&title={quote_plus(title)}&url={quote_plus(url)}&thumbnail={quote_plus(thumbnail)}&plot={quote_plus(plot)}&extra={quote_plus(extra)}&page={quote_plus(page)}'
        if url.startswith("plugin://"):
            listitem.setProperty('IsPlayable', 'true')
        elif isPlayable:
            listitem.setProperty("IsPlayable", 'true')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    except Exception as e:
        log(f"Error in add_item: {str(e)}")

def play_resolved_url(url):
    try:
        _log("play_resolved_url")
        listitem = xbmcgui.ListItem(path=url)
        listitem.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    except Exception as e:
        log(f"Error in play_resolved_url: {str(e)}")

def close_item_list():
    try:
        _log("close_item_list")
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)
    except Exception as e:
        log(f"Error in close_item_list: {str(e)}")

def read(url):
    try:
        _log("read " + url)
        f = urllib.request.urlopen(url)
        data = f.read()
        f.close()
        return data
    except Exception as e:
        log(f"Error in read: {str(e)}")
        return None

def read_body_and_headers(url, post=None, headers=[], follow_redirects=False, timeout=None):
    try:
        _log("read_body_and_headers " + url)
        if post:
            _log("read_body_and_headers post=" + post)
        if not headers:
            headers.append(["User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0"])
        ficherocookies = os.path.join(get_data_path(), 'cookies.dat')
        _log("read_body_and_headers cookies_file=" + ficherocookies)
        cj = None
        try:
            _log("read_body_and_headers importing cookielib")
            import http.cookiejar
        except ImportError:
            try:
                _log("read_body_and_headers importing ClientCookie")
                import ClientCookie
            except ImportError:
                urlopen = urllib.request.urlopen
                Request = urllib.request.Request
            else:
                urlopen = ClientCookie.urlopen
                Request = ClientCookie.Request
                cj = ClientCookie.MozillaCookieJar()
        else:
            urlopen = urllib.request.urlopen
            Request = urllib.request.Request
            cj = http.cookiejar.MozillaCookieJar()
        if cj:
            if os.path.isfile(ficherocookies):
                try:
                    cj.load(ficherocookies)
                except:
                    _log("read_body_and_headers Wrong cookie file, deleting...")
                    os.remove(ficherocookies)
            opener = urllib.request.build_opener(urllib.request.HTTPHandler(debuglevel=http_debug_log_enabled), urllib.request.HTTPCookieProcessor(cj))
            if not follow_redirects:
                opener = urllib.request.build_opener(urllib.request.HTTPHandler(debuglevel=http_debug_log_enabled), urllib.request.HTTPCookieProcessor(cj), NoRedirectHandler())
            urllib.request.install_opener(opener)
        txheaders = {header[0]: header[1] for header in headers}
        req = Request(url, post, txheaders)
        if timeout:
            import socket
            deftimeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(timeout)
            handle = urlopen(req)
            socket.setdefaulttimeout(deftimeout)
        else:
            handle = urlopen(req)
        cj.save(ficherocookies)
        if handle.info().get('Content-Encoding') == 'gzip':
            buf = StringIO(handle.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
        else:
            data = handle.read()
        info = handle.info()
        returnheaders = [[header, info[header]] for header in info]
        handle.close()
        return data, returnheaders
    except Exception as e:
        log(f"Error in read_body_and_headers: {str(e)}")
        return None, []

class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        return infourl
    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302

def find_single_match(text, pattern, index=0, flags=re.DOTALL):
    try:
        matches = re.findall(pattern, text, flags)
        return matches[index]
    except IndexError:
        return ''

def find_multiple_matches(text, pattern, flags=re.DOTALL):
    return re.findall(pattern, text, flags)

def direct_play(url):
    _log("direct_play [" + url + "]")
    title = ""
    try:
        xlistitem = xbmcgui.ListItem(title, path=url)
    except:
        xlistitem = xbmcgui.ListItem(title)
    xlistitem.setInfo("video", {"Title": title})
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(url, xlistitem)
    xbmc.Player().play(playlist)

def set_view(view_mode):
    _log("set_view [" + view_mode + "]")
    view_code = get_view_code(view_mode)
    if view_code:
        xbmc.executebuiltin("Container.SetViewMode(" + str(view_code) + ")")

def get_view_code(view_mode):
    _log("get_view_code [" + view_mode + "]")
    skin = xbmc.getSkinDir()
    if skin in ALL_VIEW_CODES.get(view_mode, {}):
        return ALL_VIEW_CODES[view_mode][skin]
    return None

def get_data_path():
    _log("get_data_path")
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo("id")
    data_path = xbmcvfs.translatePath('special://profile/addon_data/' + addon_id)
    if not xbmcvfs.exists(data_path):
        xbmcvfs.mkdirs(data_path)
    return data_path